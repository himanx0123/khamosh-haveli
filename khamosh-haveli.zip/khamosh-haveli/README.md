# 🪔 Khamosh Haveli

2D horror survival puzzle game. Ek raat, teen darwaze, ek raaz.

- Level 1: aangan ki ginti ka code
- Level 2: aaine ka ulta kram
- Level 3: kuein ki paheli
- Diya ka tel = tumhari jaan. Chhaya andhere mein shikaar karti hai.

## Play
Live: `https://<your-username>.github.io/khamosh-haveli/`

Phone par kholo, menu mein **Add to Home screen / Install app** dabao. Ye app ki tarah fullscreen aur offline chalega.

## Controls
WASD / arrows = chalo, E / Space = dekho. Phone par on-screen buttons.

## Deploy
1. Repo banao `khamosh-haveli`, saari files push karo (branch `main`).
2. Settings → Pages → Source: **GitHub Actions**.
3. Actions tab mein deploy khatam hone ka intezaar karo.

## Android APK (optional)
Live link ko https://www.pwabuilder.com par daalo aur Android package download karo.
